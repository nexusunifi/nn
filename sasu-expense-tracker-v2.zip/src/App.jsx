import React from 'react';

function App() {
  return (
    <div style={{ padding: "2rem", fontFamily: "Arial" }}>
      <h1>SASU Expense Tracker</h1>
      <p>This is a fresh deployment of your app. Ready to expand!</p>
    </div>
  );
}

export default App;
